# Samurai-Warriors
Samurai Warriors rare weapons list and the acquisition guides. Click or tap on the weapons to show the acquisition guide, then click or tap again to hide it.

Live Demo: https://anoname112.github.io/Samurai-Warriors/

Screenshot:
<br />
<a href="https://anoname112.github.io/Samurai-Warriors/">
   <img src="https://raw.githubusercontent.com/Anoname112/Samurai-Warriors/main/ss.png" title="Samurai Warriors">
</a>
